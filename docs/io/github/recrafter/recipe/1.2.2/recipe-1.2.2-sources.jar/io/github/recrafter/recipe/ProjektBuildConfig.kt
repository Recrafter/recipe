package io.github.recrafter.recipe

import kotlin.String

public object ProjektBuildConfig {
  public const val PLUGIN_NAME: String = "Recipe"

  public const val PLUGIN_VERSION: String = "1.2.2"

  public const val PLUGIN_DEVELOPER: String = "recrafter"
}
